<div class="container" role="navigation">
    <nav class="navbar sticky-top navbar-expand-md navbar-light bg-light mt-3">

        
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="show">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="contact">Contact</a></li>
                <?php if(Auth::user()&&Auth::user()->is_admin): ?>
                    <li class="nav-item"><a class="nav-link" href="show">Admin</a></li>
                <?php endif; ?>

                <?php if(Auth::user()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                    </li>


                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login">Login</a></li>

                <?php endif; ?>

            </ul>
        </div>

    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\savingWithCoupon\resources\views/Home/layouts/navbar.blade.php ENDPATH**/ ?>